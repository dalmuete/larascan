<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Login with QRCode')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12 px-4">
        <video id="video" style="width: 100%; height: 380px;" autoplay></video>
    </div>

     <?php $__env->slot('script', null, []); ?> 
        <script>
            // check
            if (!('BarcodeDetector' in window)) {
                console.warn('Browser tidak support BarcodeDetecor')
            }


            // video element
            const video = document.querySelector('#video')
            // check if device has camera
            if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
                // use video without audio
                const constraints = {
                    video: {
                        facingMode: 'environment'
                    },
                    audio: false
                }

                // start video stream
                navigator.mediaDevices.getUserMedia(constraints).then(stream => video.srcObject = stream)
            }

            // create new BarcodeDetector
            const barcodeDetector = new BarcodeDetector({
                format: ['qr_code']
            })

            // detect code function
            const detectCode = () => {
                barcodeDetector.detect(video).then(codes => {
                    if (codes.length === 0) return;

                    // console.log(codes)

                    for (const barcode of codes) {
                        // console.log(barcode.rawValue)

                        let hostname = window.location.hostname
                        let value = barcode.rawValue
                        let url = new URL(value)
                        let search = url.search

                        if (hostname == url.hostname && search.includes('session')) {
                            clearInterval(detect)
                            window.location.href = value
                        }
                    }
                }).catch(err => {
                    console.log(err)
                })
            }

            let detect = setInterval(detectCode, 100);
        </script>
     <?php $__env->endSlot(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\qrcode-login\resources\views/scan.blade.php ENDPATH**/ ?>